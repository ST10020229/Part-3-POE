/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kanban;

import javax.swing.JOptionPane;

/**
 * ST10134563
 * @author Michael mei
 * @version JDK 1.13
 * @since JDK 1.8
 */



public class taskManager 
{   
    String taskName, taskDescription, developersFirstName, developersLastName;
    int numberOfTasks, taskDuration;

   public String getTaskName()
    {
      taskName = JOptionPane.showInputDialog(null,"What is your task name?");
       return taskName;
    }
    
    public int numberOfTasks()
    {
     String tasks = JOptionPane.showInputDialog(null,"How many tasks do you want to perform?");
        numberOfTasks = Integer.parseInt(tasks);
        return numberOfTasks;
    }
    
    public String TaskDescription()
    {
        taskDescription = JOptionPane.showInputDialog(null,"Please enter a description of your task."
              + "\nNote: Description should not exceed 50 characters in length.");
     return taskDescription;
    }
    
    public boolean checkTaskDescription(String taskDescription)
    {
      if(taskDescription.length() <= 50)
      {
        return true;
      }
      else 
      {
      return false;
      }
    }
    
    public String DeveloperDetails()
    {
        developersFirstName = JOptionPane.showInputDialog(null,"Please enter the developer's first name.",null,JOptionPane.QUESTION_MESSAGE);
        developersLastName = JOptionPane.showInputDialog(null,"Please enter the developer's last name.",null,JOptionPane.QUESTION_MESSAGE);
        return developersFirstName+developersLastName;
    }
    
    public int taskDuration()
    {
        taskDuration = Integer.parseInt(JOptionPane.showInputDialog(null,"How many hours is this task going to take?",null,JOptionPane.QUESTION_MESSAGE)); 
        return taskDuration;
    }
    
    public String createTaskID(String taskName, int numberOfTasks, String developersLastName)
    {
        char a,b,c,d,e;
        int i = 0;
        a = taskName.charAt(i);
        b = developersLastName.charAt(developersLastName.length()-3);
        c = developersLastName.charAt(developersLastName.length()-2);
        d = developersLastName.charAt(developersLastName.length()-1);
        i = 1;   
        e = taskName.charAt(i);
          
        String A = String.valueOf(a);
        String B = String.valueOf(e);
        String no = String.valueOf(numberOfTasks);
        String C = String.valueOf(b);
        String D = String.valueOf(c);
        String E = String.valueOf(d);
        String TaskID = A+B+":"+no+":"+C+D+E;
        return TaskID;
    }
    
    public String taskStatus()
    {
     String toDo = "To Do";   
      String done = "Done";
       String doing = "Doing";
        String taskStatus = null;
       String Status = JOptionPane.showInputDialog(null,"What is the status of your task?\n"+toDo+"\n"+done+"\n"
                       +doing,null,JOptionPane.QUESTION_MESSAGE);
      int task = Integer.parseInt(Status);

       switch(task)
       {
           case 1 : taskStatus = toDo; break;
           case 2 : taskStatus = done; break;
           case 3 : taskStatus = doing; break;
       }
        return taskStatus;
    }
    
    public String printTaskDetails(String taskName, String TaskID, String taskDescription, String taskStatus)
    {
     String printTaskDetails1 = taskName;   
      String printTaskDetails2 = TaskID;
       String printTaskDetails3 = taskDescription;
      String printTaskDetails4 = taskStatus;
       JOptionPane.showMessageDialog(null,printTaskDetails1+printTaskDetails2+printTaskDetails3+printTaskDetails4);
        return printTaskDetails1+printTaskDetails2+printTaskDetails3+printTaskDetails4;
    }
    
    public int returnTotalHours(int taskDuration)
    {   
        int returnTotalHours = taskDuration;
        
        while(taskDuration <= 0)
        {
            JOptionPane.showMessageDialog(null,returnTotalHours);
            
            while(taskDuration == taskDuration)
            {
                JOptionPane.showMessageDialog(null,returnTotalHours);
                
                while(taskDuration == taskDuration)
                { 
                    JOptionPane.showMessageDialog(null,returnTotalHours);
                }
            }
        }
        return returnTotalHours;
    }
}

