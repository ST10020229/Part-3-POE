/*
 \\
 */
package kanban;
import java.util.Arrays;
import java.util.Scanner;
/**
 * ST10020229
 * @author Neo Hlanyane
 * @version JDK 1.13
 * @since JDK 1.8
 */
public class TaskArray {
    
    public static void printTaskDetails(int amount,String taskName[],String taskDes[],String devDet[],int taskDur[],String status[],String[]ID, int taskNum){
        taskNum=0;
        for(int i=0;i<amount;i++){
            ID[i]=createTaskID(taskName,devDet,taskNum,amount,ID);
                System.out.println("Task name:" + "" + taskName[i] + "\nTask description:" + "" + taskDes[i] + "\nDeveloper Details:" + "" + devDet[i] +"\nTask Duration:" 
                        + "" + taskDur[i] + "\nTask Status:" + "" + status[i] + "\nTask ID" + " "+ ID[i] + "\nTask Number:" + "" + taskNum);
                taskNum++;
            }
        
    }
    public static String createTaskID (String taskName[],String [] devDet, int taskNum, int amount, String ID[]){
        String id ="";
        for(int i=0;i<amount;i++)
         id=taskName[i].substring(0,2)+":"+taskNum+":"+devDet[i].substring(devDet[i].length()-4,devDet[i].length());
        
       return id.toUpperCase();
    
    }
    public static void searchDev(String taskName[],String devDet[],String status[], int amount){
        Scanner lb = new Scanner(System.in);

         System.out.println("Enter the task you would like to search");
           String find = lb.nextLine();
        for(int i =0; i<amount;i++){   
        if(devDet[i].contains(find))
                System.out.println("Developer: " + devDet[i] + "\nTask Name: " + taskName[i] + "\nTask Status: " + status[i]);
       
    }
        

    }
    public static void search(String taskName[],String devDet[],String status[], int amount){
                Scanner lb = new Scanner(System.in);

         System.out.println("Enter the task you would like to search");
           String find = lb.nextLine();
        for(int i =0; i<amount;i++){   
        if(taskName[i].contains(find))
                System.out.println("Developer: " + devDet[i] + "\nTask Name: " + taskName[i] + "\nTask Status: " + status[i]);
        
    }
    }
    
    public static void delete(int amount,String [] taskName,String[]devDet, String[] status, int [] taskDur){
        Scanner lb = new Scanner(System.in);
    System.out.println("Enter the task you would like to search");
           String find = lb.nextLine();
           int delete = Arrays.asList(taskName).indexOf(find);
        for(int i =delete; i<amount-1;i++){   
        if(taskName[i].contains(find))
          // System.out.println( Arrays.asList(taskName).indexOf(find)); 
            taskName[i] = taskName[i+1];
           taskDur[i] = taskDur[i+1];
             status[i] = status[i+1];
             devDet[i] = devDet[i+1];
             System.out.println(taskName[i] + "\n"+taskDur[i]+"\n"+status[i]+"\n"+devDet[i]);
    
   // for(int i = removeIndex; i < ints.length -1; i++){
     //   ints[i] = ints[i + 1];
}
    }
    public static void done(String [] status, int amount, String [] taskName, String devDet[], int[] taskDur){
        for(int i =0; i<amount;i++)   
        if(status[i].contains("Done"))
                System.out.println("Developer: " + devDet[i] + "\nTask Name: " + taskName[i] + "\nTask Duration: " + taskDur[i]);
    }
    
    public static void maxNumber(int [] taskDur, String [] devDet){
        int maxVal = Integer.MIN_VALUE;
        for(int i=0; i < taskDur.length; i++){
        if(taskDur[i] > maxVal)
           maxVal=taskDur[i];
}
          System.out.println("Developer :" + "" + devDet[findIndex(taskDur,maxVal)] + "\nDuratation: " + "" + taskDur[findIndex(taskDur,maxVal)] );


    }

    public static int findIndex(int taskDur[], int t)
        {

            // if array is Null
            if (taskDur == null) {
                return -1;
            }

            // find length of array
            int len = taskDur.length;
            int i = 0;

            // traverse in the array
            while (i < len) {

                // if the i-th element is t
                // then return the index
                if (taskDur[i] == t) {
                    return i;
                }
                else {
                    i = i + 1;
                }
            }
            return -1;
        }
public  void input (){
    {
        Scanner kb = new Scanner(System.in);
        Scanner lb = new Scanner(System.in);
        
        System.out.println("Please enter 1 to Add Tasks, 2 to Show Report or 3 to End Program");
            int access = kb.nextInt();
             while(access<3){
                 if(access == 1){
        System.out.println("How many tasks would you like to enter?");
            int amount = kb.nextInt();
            
                String [] taskName = new String[amount];
                String [] devDet = new String[amount];
                String [] taskDes = new String[amount];
                int[] taskDur = new int[amount];
                String [] status = new String[amount];
                String [] ID = new String[amount];
                
                int taskNum=0;
                
              
                   
            for(int i=0;i<amount;i++){
                
                 //System.out.println("Please enter task description");
                  //taskDes[i] = lb.nextLine();
                 System.out.println("Please enter developer details");
                  devDet[i] = lb.nextLine();
                 System.out.println("Please enter task name");
                  taskName[i]=lb.nextLine();
                 System.out.println("Please enter task duration");
                   taskDur [i] = kb.nextInt();
                  System.out.println("Please enter 1 for Done, 2 for Doing and 3 for To Do");
                  int  taskStatus = kb.nextInt();
                    if(taskStatus==1)
                            status[i] = "Done";
                    else if (taskStatus == 2)
                            status[i] = "Doing";
                    else 
                            status[i] = "To Do";
            }
            
            /*
d. Search for all tasks assigned to a developer and display the Task Name and Task Status. Not done yet
e. Delete a task using the Task Name. Not done yet
f. Display a report that lists the full details of all captured tasks. Done and tested
            */ 
            
            System.out.println("Press 1 to view tasks, 2 to view completed tasks, 3 to search a task name, \n4 to search for a task developer, 5 to view longest task or 6 to delete a task");
                int choice = kb.nextInt();
                     switch (choice) {
                         case 1:
                             printTaskDetails(amount,taskName,taskDes,devDet,taskDur,status,ID,taskNum);
                             break;
                         case 2:
                             done(status,amount, taskName,devDet,  taskDur);
                             break;
                         case 3:
                             search(taskName,devDet,status, amount);
                             break;
                         case 4:
                             searchDev( taskName, devDet,status, amount);
                             break;
                         case 5:
                             maxNumber(taskDur,devDet);
                             break;
                         case 6:
                             delete(amount,taskName,devDet,status,taskDur);
                             
                             // done(status);
                             //else if(choice==2)
                             
                             //System.out.println(maxNumber(taskDur));
                             
                             // TODO code application logic here
                             break;
                         default:
                             break;
                     }
    }
                  if(access == 2)
                        System.out.println("Coming soon!");
                         System.out.println("Please enter 1 to Add Tasks, 2 to Show Report or 3 to End Program");
                       access = kb.nextInt();
               }
              if(access == 3)
                    System.out.println("Program Terminated!");
                
    }
}


}
           
         
        
         
    
    
   
     
    
        
         
         